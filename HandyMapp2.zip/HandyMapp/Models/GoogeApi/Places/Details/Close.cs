﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HandyMapp.Models.GoogeApi.Places.Details
{
    public class Close
    {
        public int day { get; set; }
        public string time { get; set; }
    }
}
