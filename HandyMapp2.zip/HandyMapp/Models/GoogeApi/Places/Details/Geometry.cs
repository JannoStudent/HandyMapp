﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HandyMapp.Models.GoogeApi.Places.Details
{
    public class Geometry
    {
        public Location location { get; set; }
        public Viewport viewport { get; set; }
    }

}
