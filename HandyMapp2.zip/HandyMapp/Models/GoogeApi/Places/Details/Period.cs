﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HandyMapp.Models.GoogeApi.Places.Details
{
    public class Period
    {
        public Close close { get; set; }
        public Open open { get; set; }
    }
}
