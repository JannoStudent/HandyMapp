﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Handy_Mapp.Models.Navigation
{
    public enum MobilityType
    {
        Scooter, Weelchair, Walker, Cane
    }
}
