﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Handy_Mapp.Models.Navigation
{
    public enum ObstacleType
    {
        Bridge, Stairs, NarrowEntrances, SteepSlopes, BadSidedwalks 
    }
}
